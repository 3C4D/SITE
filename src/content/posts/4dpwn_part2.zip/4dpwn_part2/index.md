---
title: 4DPwn Part 2
published: 2024-12-31
description: An adventure through an unknown attack surface
tags: [research, web]
image: /images/barbhack_2024/barback.jpg
category: Research
draft: false
---

## A bit of Context
4D is a French company founded in 1984 that offers a whole range of tools for the development of professional applications. These applications
cover everything from **web servers** and **relational databases** to **thick clients**.

## In the previous episode...
With [Issam](https://hacknshare.com/), we were able to observe that this technology was not widely used (around 6.000 on Shodan). In this sense,
its unexplored attack surface represents an interesting field of study.

The first part of this series can be found here: **ARTICLE LINK**. It covers basic 4D functionalities, secure development practices and template
injection vulnerabilities.

This part will cover :
- Code injection via insecure file upload functionality
- Verb Tampering attacks
- A final word on this technology and many others that deserve a closer look.

## What if we have an insecure file upload functionality on a 4D app ?
A fairly common vulnerability encountered on web applications is the lack of sanitization in a file upload functionality.

Exploiting such a vulnerability is not necessarily possible :
1. In the case of an application using PHP, it would be possible to upload a PHP file and use it (knowing its path) to execute commands on the victim system.
2. An application does not directly use the files that store its back-end code. For example, with a python application, uploading a file containing python
code won't normally be of much help to us.

### Ok but what do we upload ?
From what we've been able to test and read in the vendor's documentation, 4D doesn't use its server-side files "directly" (as PHP does). However, it seems
possible to use a file that contains tags.
More precisely, it is possible to **FORCE** the interpretation of these tags with a precise extension, **SHTML** (see doc).

From what we can read in the first part of this adventure, interpreting arbitrary 4D tags can lead to remote code execution. That's what we're going to test...

### Let's Test !
To learn how to upload a file, we can refer to [WEB GET BODY PART](https://doc.4d.com/4Dv18/4D/18.4/WEB-GET-BODY-PART.301-5232846.fe.html) primitive page on
the vendor's documentation.

The example describe how to receive a file after a POST request but lacks verification on the uploaded content. We can therefore use it to describe the
exploitation and remediation of the problem

```
C_TEXT($vPartName;$vPartMimeType;$vPartFileName;$vDestinationFolder)
C_BLOB($vPartContentBlob)
C_LONGINT($i)
$vDestinationFolder:="C:/a/folder/"

For($i;1;WEB GET BODY PART COUNT)
	WEB GET BODY PART($i;$vPartContentBlob;$vPartName;$vPartMimeType;$vPartFileName)
	If($vPartFileName#"")
		BLOB TO DOCUMENT($vDestinationFolder+$vPartFileName;$vPartContentBlob)
    End if
End for
WEB SEND HTTP REDIRECT("/")
```

using this code as a [4D Method](https://developer.4d.com/docs/fr/20/Concepts/methods) we can upload using the following form, also present in the example page but a bit modified :
```html
<body>
        <form enctype="multipart/form-data" action="/4DACTION/GetFile/" method="post">
            file: <input name="file2" type="file"><br>
            <input type="submit">                    
        </form>     
</body>
```

file : test.**shtml**
This example shows the output of the command ipconfig

### Remediation
Although the exploit is specific to 4D technology, the vulnerability exploited is rather “common”. When we want a user to send a file to the website, we need to check several things to make sure they can't do nothing wrong :
- **Extension :** whitelist rather than blacklist
- **Content :** if possible, check magic bytes, MIME type and/or file structure using appropriate libraries (not necessarily the case for 4D)
- **Destination :** in order to avoid Path Traversal vulnerabilities, check that the file's destination path is not controllable in any way by the user (in particular by the filename supplied)

### 4D Specific remediation
Using the 4D code seen above, we will try to patch the vulnerability with a few additional checks :
- **Extension :** this is a gallery application, we'll whitelist the png and jpg extensions
- **Content :** to be on the safe side, we'll check the MIME type of the files (always png or jpg).
- **Destination :** we should remove folder separators ('/' for linux, '\' for windows, and '.') present in the filename.

```
C_TEXT($vPartName;$vPartMimeType;$vPartFileName;$vDestinationFolder)
C_BLOB($vPartContentBlob)
C_LONGINT($i)
$vDestinationFolder:="C:/truc/machin/"

For($i;1;WEB GET BODY PART COUNT)
	WEB GET BODY PART($i;$vPartContentBlob;$vPartName;$vPartMimeType;$vPartFileName)
	If($vPartFileName#"")
		BLOB TO DOCUMENT(Temporary folder+$vPartFileName;$vPartContentBlob)
        IF((File(Temporary folder+$vPartFileName).extension()="jpg")|((File(Temporary folder+$vPartFileName).extension()="png")))
            # VERIFIER SI Y'A DES SLASHS
    End if
End for
WEB SEND HTTP REDIRECT("/")
```

## Verb Tampering EZ 

![image](/images/barbhack_2024/dontmindme.png)

![[code_recuperation_param_http.png]]
![[Pasted image 20241230190729.png]]
## What if we could reach the local PHP Server ?

## Next reflexion ? and the others ?

4D est une technologie méconnue, mais qui dispose d'un panel extrêmement étendu, ce qui lui confère une surface d'attaque assez grande, donnant une marge d'erreur assez large aux créateurs. Le fait est que ce n'est surement pas la seule. De nombreuses technologies peu connues attendent que quelqu'un sy attarde à la recherche de vulnérabilités... Cela peut être nous, ou bien une menace.

Cette série d'article a donc aussi pour but de porter l'attention sur les sujets de sécurité comme celui-ci, très peu abordés mais qui constitue une base trop grande d'utilisateurs pour être ignoré.

Merci.